python frameworks_to_modelfile_maestro.py --api_name keras --model custom --custom alexnet --outfile alexnet_keras_custom.m
