#ifndef MAESTRO_DSE_DESIGN_OPTIONS_HPP_
#define MAESTRO_DSE_DESIGN_OPTIONS_HPP_

namespace maestro {

  namespace DSE {

    enum class OpType{FloatPoint, FixedPoint};
  }; // End of namespace DSE
}; // End of namesapce maestro

#endif
